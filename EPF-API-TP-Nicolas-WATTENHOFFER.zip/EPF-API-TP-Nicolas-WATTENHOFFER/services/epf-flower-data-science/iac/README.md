Folder to store terraform files or other files for infra as code tools
