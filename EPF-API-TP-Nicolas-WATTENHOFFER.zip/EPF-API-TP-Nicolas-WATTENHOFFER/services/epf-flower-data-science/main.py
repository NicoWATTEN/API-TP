import uvicorn
from src.app import get_application

# Get the FastAPI application instance
app = get_application()

# Run the FastAPI application using Uvicorn
if __name__ == "__main__":
    """
    Main script to run the FastAPI application using Uvicorn.

    - Import the FastAPI application instance.
    - Run Uvicorn with the specified parameters.
    """
    uvicorn.run("main:app", port=8080, workers=2)

