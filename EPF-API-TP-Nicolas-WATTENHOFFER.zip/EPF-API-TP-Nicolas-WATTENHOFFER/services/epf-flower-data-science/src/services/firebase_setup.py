import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import os

# Function to initialize Firestore and return the Firestore client
def initialize_firestore():
    """
    Initialize Firestore and return the Firestore client.

    The service account file 'credit_firebase.json' is expected to be located in the '../config/' directory.

    :return: Firestore client instance.
    """
    # Get the current directory of this script
    current_dir = os.path.dirname(__file__)

    # Construct the file path to the service account file
    service_account_path = os.path.join(current_dir, '..', 'config', 'credit_firebase.json')
    print(f'Path to service account file: {service_account_path}')

    # Load the Firebase credentials from the service account file
    cred = credentials.Certificate(service_account_path)

    # Initialize the Firebase app with the loaded credentials
    firebase_admin.initialize_app(cred)

    # Get and return the Firestore client
    db = firestore.client()
    return db

# Function to create a Firestore collection with sample data
def create_firestore_collection(db):
    """
    Create a Firestore collection with sample data.

    The collection is named 'parameters' with a document named 'model_params' and sample parameters.

    :param db: Firestore client instance.
    """
    # Reference to the 'parameters' collection and 'model_params' document
    doc_ref = db.collection('parameters').document('model_params')

    # Set sample parameters in the document
    doc_ref.set({
        'n_estimators': 100,
        'criterion': 'gini'
    })

# Script execution block
if __name__ == '__main__':
    try:
        # Try initializing Firestore and creating a collection with sample data
        db = initialize_firestore()
        create_firestore_collection(db)
    except Exception as e:
        # Print an error message if an exception occurs during initialization
        print(f"An error occurred during initialization: {e}")
