import logging
import sys

# Function to set up a basic logger configuration and return a logger instance
def setup_logger():
    """
    Set up a basic logger configuration and return a logger instance.

    :return: Logger instance configured with a stream handler.
    """
    # Configure the root logger with INFO level, a specific format, and a stream handler
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )

    # Get a logger instance for the current module (__name__)
    logger = logging.getLogger(__name__)

    # Return the configured logger
    return logger
