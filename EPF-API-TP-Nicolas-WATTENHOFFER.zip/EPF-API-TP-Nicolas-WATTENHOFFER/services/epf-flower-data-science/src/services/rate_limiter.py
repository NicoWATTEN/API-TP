# services/rate_limiter.py
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse

# Create a Limiter instance for rate limiting based on remote addresses
limiter = Limiter(key_func=get_remote_address)

# Handler for handling RateLimitExceeded exceptions
async def _rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded):
    """
    Handle RateLimitExceeded exceptions by returning a JSONResponse with a 429 status code.

    :param request: The FastAPI request object.
    :param exc: The RateLimitExceeded exception.
    :return: JSONResponse indicating rate limit exceeded.
    """
    return JSONResponse(
        status_code=429,
        content={"detail": "Rate limit exceeded"}
    )

