import joblib
import os
from sklearn.ensemble import RandomForestClassifier
from ..config.config import load_model_parameters

# Function to train an Iris flower classification model
def train_iris_model(X_train, y_train):
    """
    Train an Iris flower classification model.

    :param X_train: Training data features (independent variables).
    :param y_train: Training data labels (dependent variable).
    :return: Trained RandomForestClassifier model.
    """
    # Load model parameters from the configuration
    params = load_model_parameters()

    # Initialize a RandomForestClassifier model with specified parameters
    model = RandomForestClassifier(**params)

    # Train the model with the provided training data
    model.fit(X_train, y_train)

    # Define the directory to save the model
    model_dir = 'src/models'

    # Create the model directory if it doesn't exist
    if not os.path.isdir(model_dir):
        os.makedirs(model_dir, exist_ok=True)

    # Define the path to save the trained model
    model_path = os.path.join(model_dir, 'iris_model.pkl')

    # Save the trained model using joblib
    joblib.dump(model, model_path)

    # Return the trained model
    return model


