import kaggle.api
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC


def download_dataset():
    """Download our dataset iris and save it in the save_dir directory"""
    kaggle.api.authenticate()
    dataset_name = "uciml/iris"
    save_dir = "services/epf-flower-data-science/src/data/iris.csv"
    kaggle.api.dataset_download_files(dataset_name, path=save_dir, unzip=True)


download_dataset()

#

# def load_dataset_kaggle():
#     """transform ion a dataset json file and return it"""
#     df = pd.read_csv("services/epf-flower-data-science/src/data/iris.csv")
#     return df.to_join(orient="records")
#
# #
#
# def preprocessing_data():
#     """
#     delete 5 first letters of the column species and return the data set in json
#     """
#     df = pd.read_csv("services/epf-flower-data-science/src/data/iris.csv")
#     df = df.drop("Id", axis=1)
#     df["Species"] = df["Species"].map({'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2})
#     df = df.rename(columns={"Species": "target"})
#     #df["Species"] = df["Species"].apply(lambda x: x[5:])
#     return df.to_json(orient="records")
#
