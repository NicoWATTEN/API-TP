from fastapi import APIRouter
from src.schemas.message import MessageResponse  # Import the MessageResponse schema

# Create an APIRouter instance
router = APIRouter()

# Define a FastAPI route
@router.get("/hello/{name}", name="Demo route", response_model=MessageResponse)
def hello(name: str) -> MessageResponse:
    """
    A FastAPI route that returns a greeting message.

    :param name: The name to include in the greeting.
    :return: A MessageResponse containing the greeting message.
    """
    return MessageResponse(message=f"Hello {name}, from FastAPI test route !")
