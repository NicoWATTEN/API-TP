from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

# Clé secrète pour encoder et décoder les tokens JWT
SECRET_KEY = "nico-key"
ALGORITHM = "HS256"
#Key Type: Use of a shared secret key (symmetric key).
#Signing and Verification Process: Utilization of an HMAC (Hash-based Message Authentication Code) hash function
#with SHA-256 to sign and verify the token.
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Définition du schéma OAuth2 pour la gestion des tokens
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Fonction pour créer un token d'accès JWT
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """
    Crée un token d'accès JWT avec les données spécifiées.

    :param data: Dictionnaire contenant les données à inclure dans le token.
    :param expires_delta: Durée d'expiration du token (optionnelle).
                         Si non spécifié, la durée par défaut est de 15 minutes.
    :return: Token JWT encodé.
    """
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Fonction pour vérifier et décoder un token JWT
def verify_token(token: str, credentials_exception):
    """
    Vérifie et décoded un token JWT.

    :param token: Token JWT à vérifier et décoder.
    :param credentials_exception: Exception à déclencher en cas d'erreur.
    :return: Nom d'utilisateur extrait du token.
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        return username
    except JWTError:
        raise credentials_exception

# Fonction pour obtenir l'utilisateur actuel à partir du token
def get_current_user(token: str = Depends(oauth2_scheme)):
    """
    Obtient l'utilisateur actuel à partir du token d'accès.

    :param token: Token d'accès JWT extrait de la requête HTTP.
    :return: Nom d'utilisateur de l'utilisateur actuel.
    :raise: HTTPException avec code 401 si l'authentification échoue.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Impossible de valider les informations d'identification",
        headers={"WWW-Authenticate": "Bearer"},
    )
    return verify_token(token, credentials_exception)
