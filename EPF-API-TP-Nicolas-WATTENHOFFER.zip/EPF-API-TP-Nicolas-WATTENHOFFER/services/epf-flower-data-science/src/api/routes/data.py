# routers/data.py
from fastapi.responses import RedirectResponse
from fastapi import APIRouter, HTTPException
from src.services.data import *
import pandas as pd
import opendatasets as od
import pandas as pd
from fastapi import HTTPException
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from fastapi import APIRouter
from src.services.training import train_iris_model
from src.schemas.iris import IrisModel
from src.schemas.iris import IrisModelPrediction
from src.services.firebase_setup import initialize_firestore
from typing import List
import logging
import joblib
from fastapi import APIRouter, HTTPException
from src.services.utils import setup_logger
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from src.api.routes.authentication import create_access_token, get_current_user
from src.services.rate_limiter import limiter
from fastapi import APIRouter, Request
from src.services.rate_limiter import limiter, get_remote_address
from fastapi import HTTPException

# Création d'un routeur API FastAPI
router = APIRouter()
# Configuration du logger
logger = setup_logger()

# Route pour générer un token d'accès
@router.post("/token")
async def generate_token(form_data: OAuth2PasswordRequestForm = Depends()):
    """
    Génère un token d'accès JWT en fonction des informations d'identification fournies.

    :param form_data: Informations d'identification fournies via le formulaire OAuth2.
    :return: Token d'accès JWT en cas de succès.
    :raise: HTTPException avec code 401 en cas d'informations d'identification invalides.
    """
    if form_data.username == "nico" and form_data.password == "nico":
        access_token = create_access_token(data={"sub": form_data.username})
        return {"access_token": access_token, "token_type": "bearer"}
    else:
        raise HTTPException(status_code=401, detail="Informations d'identification invalides")

# Route pour télécharger le jeu de données Iris
@router.get("/download-iris")
async def download_iris_dataset():
    """
    Télécharge le jeu de données Iris depuis Kaggle.

    :return: Message de réussite ou exception HTTP en cas d'erreur.
    """
    logger.info("Loading Iris Data")
    try:
        df = pd.read_csv('src/data/iris/Iris.csv')
        logger.info("Iris Data loaded successfully")
        return df.to_dict(orient='records')
    except FileNotFoundError as e:
        logger.error(f"Error in /load-iris route: {e}")
        raise HTTPException(status_code=404, detail="File not found")

# Route pour charger le jeu de données Iris
@router.get("/load-iris")
async def load_iris_dataset():
    """
    Charge le jeu de données Iris à partir du fichier CSV.

    :return: Dictionnaire représentant le jeu de données ou exception HTTP en cas d'erreur.
    """
    logger.info("Loading Iris Data")
    try:
        df = pd.read_csv('src/data/iris/Iris.csv')
        logger.info("Iris Data loaded successfully")
        return df.to_dict(orient='records')
    except FileNotFoundError as e:
        logger.error(f"Error in /load-iris route: {e}")
        raise HTTPException(status_code=404, detail="File not found")

# Route pour traiter le jeu de données Iris
@router.post("/process-iris")
async def process_iris_dataset(iris_data_list: List[IrisModel]):
    """
    Traite le jeu de données Iris en effectuant une normalisation.

    :param iris_data_list: Liste d'objets IrisModel à traiter.
    :return: Liste de dictionnaires représentant les données traitées ou exception HTTP en cas d'erreur.
    """
    logger.info("Processing Iris Data")
    try:
        df = pd.DataFrame([iris.dict() for iris in iris_data_list])
        df_numeric = df.drop(columns=['species'])
        scaler = StandardScaler()
        df_scaled = scaler.fit_transform(df_numeric)
        df_scaled = pd.DataFrame(df_scaled, columns=df_numeric.columns).to_dict(orient='records')
        logger.info("Iris Data processed successfully")
        return df_scaled
    except Exception as e:
        logger.error(f"Error in /process-iris route: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Route pour diviser le jeu de données Iris
@router.post("/split-iris")
async def split_iris_dataset(df: List[IrisModel], test_size: float = 0.2):
    """
    Divise le jeu de données Iris en ensembles d'entraînement et de test.

    :param df: Liste d'objets IrisModel à diviser.
    :param test_size: Proportion du jeu de données à utiliser pour le test (par défaut 20%).
    :return: Dictionnaire contenant les ensembles d'entraînement et de test ou exception HTTP en cas d'erreur.
    """
    logger.info("Processing Iris Data")
    try:
        df = pd.DataFrame([iris.dict() for iris in iris_data_list])
        df_numeric = df.drop(columns=['species'])
        scaler = StandardScaler()
        df_scaled = scaler.fit_transform(df_numeric)
        df_scaled = pd.DataFrame(df_scaled, columns=df_numeric.columns).to_dict(orient='records')
        logger.info("Iris Data processed successfully")
        return df_scaled
    except Exception as e:
        logger.error(f"Error in /process-iris route: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Route pour entraîner le modèle Iris
@router.post("/train-model")
async def train_model(data: List[IrisModel], current_user: str = Depends(get_current_user)):
    """
    Entraîne un modèle d'apprentissage automatique sur le jeu de données Iris.

    :param data: Liste d'objets IrisModel à utiliser pour l'entraînement.
    :param current_user: Nom d'utilisateur de l'utilisateur actuel.
    :return: Message de réussite ou exception HTTP en cas d'erreur.
    """
    logger.info("Training Iris model")
    try:
        df = pd.DataFrame([item.dict() for item in data])
        X = df.drop(columns=['species'])
        y = df['species']
        model = train_iris_model(X, y)
        logger.info("Modèle Iris entraîné avec succès")
        return {"message": "Modèle entraîné avec succès"}
    except Exception as e:
        logger.error(f"Erreur dans la route /train-model : {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Route pour effectuer des prédictions avec le modèle Iris
@router.post("/predict")
@limiter.limit("5/minute")
async def make_prediction(request: Request, data: List[IrisModelPrediction]):
    """
    Effectue des prédictions avec le modèle Iris préalablement entraîné.

    :param request: Objet Request FastAPI.
    :param data: Liste d'objets IrisModelPrediction à utiliser pour les prédictions.
    :return: Dictionnaire contenant les prédictions ou exception HTTP en cas d'erreur.
    """
    logger.info("Effectuation de prédictions")
    try:
        model = joblib.load('src/models/iris_model.pkl')
        df = pd.DataFrame([item.dict() for item in data])
        predictions = model.predict(df)
        logger.info("Prédictions effectuées avec succès")
        return {"predictions": predictions.tolist()}
    except Exception as e:
        logger.error(f"Erreur dans la route /predict : {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Initialisation de la connexion à Firestore
db = initialize_firestore()

# Route pour obtenir les paramètres du modèle
@router.get("/get-parameters")
async def get_parameters():
    """
    Obtient les paramètres du modèle depuis Firestore.

    :return: Dictionnaire contenant les paramètres ou message indiquant l'absence de paramètres.
    """
    logger.info("Obtention des paramètres")
    try:
        params_ref = db.collection('parameters').document('model_params')
        params = params_ref.get()
        if params.exists:
            logger.info("Paramètres récupérés avec succès")
            return params.to_dict()
        else:
            return {"message": "Aucun paramètre trouvé"}
    except Exception as e:
        logger.error(f"Erreur dans la route /get-parameters : {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Route pour mettre à jour les paramètres du modèle
@router.put("/update-parameters")
async def update_parameters(new_params: dict):
    """
    Met à jour les paramètres du modèle dans Firestore.

    :param new_params: Dictionnaire contenant les nouveaux paramètres.
    :return: Message de réussite ou exception HTTP en cas d'erreur.
    """
    logger.info("Updating parameters")
    try:
        params_ref = db.collection('parameters').document('model_params')
        params_ref.update(new_params)
        logger.info("Parameters updated successfully")
        return {"message": "Parameters updated"}
    except Exception as e:
        logger.error(f"Error in /update-parameters route: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Route pour ajouter de nouveaux paramètres dans Firestore
@router.post("/add-parameters")
async def add_parameters(new_params: dict):
    """
    Ajoute de nouveaux paramètres dans Firestore.

    :param new_params: Dictionnaire contenant les nouveaux paramètres.
    :return: Message de réussite ou exception HTTP en cas d'erreur.
    """
    logger.info("Adding new parameters")
    try:
        params_ref = db.collection('parameters').document('new_model_params')
        params_ref.set(new_params)
        logger.info("New parameters added successfully")
        return {"message": "Parameters added"}
    except Exception as e:
        logger.error(f"Error in /add-parameters route: {e}")
        raise HTTPException(status_code=500, detail=str(e))


