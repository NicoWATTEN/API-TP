# API Router for FastAPI.
from fastapi import APIRouter
from src.api.routes import hello  # Import the hello route
from src.api.routes.data import router as data_router  # Import the data router

# Create an APIRouter instance
router = APIRouter()

# Include the routes from the hello router with the "Hello" tag
router.include_router(hello.router, tags=["Hello"])

# Include the routes from the data router with the "Data" tag
router.include_router(data_router, tags=["Data"])


