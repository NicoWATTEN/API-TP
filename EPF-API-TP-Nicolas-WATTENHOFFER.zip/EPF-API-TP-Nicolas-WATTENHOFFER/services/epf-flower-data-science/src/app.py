from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from src.api.router import router

# Function to get the FastAPI application instance
def get_application() -> FastAPI:
    """
    Get the FastAPI application instance.

    :return: FastAPI application configured with title, description, version, CORS, and router.
    """
    # Create a FastAPI instance with specified metadata
    application = FastAPI(
        title="epf-flower-data-science",
        description="""Fast API""",
        version="1.0.0",
        redoc_url=None,
    )

    # Redirect the root endpoint to the documentation
    @application.get("/")
    def re_doc():
        return RedirectResponse(url="/docs")

    # Add CORS middleware to handle Cross-Origin Resource Sharing
    application.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include the defined router in the application
    application.include_router(router)

    # Return the configured FastAPI application
    return application
