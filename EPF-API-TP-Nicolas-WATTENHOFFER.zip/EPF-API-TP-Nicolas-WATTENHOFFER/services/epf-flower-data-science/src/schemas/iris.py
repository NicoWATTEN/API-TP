from pydantic import BaseModel

# Define a Pydantic model for representing Iris flower data
class IrisModel(BaseModel):
    """
    Pydantic model for representing Iris flower data.

    Fields:
    - sepal_length: Length of the sepal.
    - sepal_width: Width of the sepal.
    - petal_length: Length of the petal.
    - petal_width: Width of the petal.
    - species: Iris species.
    """
    sepal_length: float
    sepal_width: float
    petal_length: float
    petal_width: float
    species: str

# Define a Pydantic model for representing Iris flower data used in predictions
class IrisModelPrediction(BaseModel):
    """
    Pydantic model for representing Iris flower data used in predictions.

    Fields:
    - sepal_length: Length of the sepal.
    - sepal_width: Width of the sepal.
    - petal_length: Length of the petal.
    - petal_width: Width of the petal.
    """
    sepal_length: float
    sepal_width: float
    petal_length: float
    petal_width: float
