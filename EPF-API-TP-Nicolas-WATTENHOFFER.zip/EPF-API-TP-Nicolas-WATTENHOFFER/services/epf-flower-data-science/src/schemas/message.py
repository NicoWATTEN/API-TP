from src.schemas.camelcase import CamelCase

# Define a Pydantic model for a message response with camelCase configuration
class MessageResponse(CamelCase):
    """
    Pydantic model for a message response.

    Inherits from CamelCase, which is configured to use camelCase for field names.
    """
    message: str
