import json
import os

# Function to load model parameters from a JSON file
def load_model_parameters():
    """
    Load model parameters from a JSON file.

    The JSON file should be named 'model_parameters.json' and located in the same directory as this script.

    :return: Dictionary containing model parameters.
    """
    # Get the current directory of this script
    current_dir = os.path.dirname(__file__)

    # Construct the file path to the 'model_parameters.json' file
    file_path = os.path.join(current_dir, 'model_parameters.json')

    # Read and parse the JSON file to obtain the model parameters
    with open(file_path) as f:
        params = json.load(f)

    # Return the loaded model parameters as a dictionary
    return params
